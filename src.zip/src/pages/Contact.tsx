import './style/contact.scss'

export default function Contact() {
    return(
        <div className='contact'>
            This is About  Pages
        </div>
    )
}