export default function Cart(){
    return (
        <div>
            This is Cart Pages
        </div>
    )
}