import './style/product.scss'

export default function Product() {
    return(
        <div className='product'>
            This is Product Pages
        </div>
    )
}