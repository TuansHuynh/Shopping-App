import './style/about.scss'

export default function About() {
    return(
        <div className='about'>
            This is About  Pages
        </div>
    )
}