import { Outlet } from 'react-router-dom'
import './assets/App.scss'

export default function App() {
   return (
      <>
         <Outlet/>
      </>
   )
}

