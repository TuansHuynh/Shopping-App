export default function SignUp() {
    return (
        <div className="signup">
            This is SignUp
            </div>
    )
}