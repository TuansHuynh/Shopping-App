export default function Footer() {
    return (
        <div className="footer">
            This is Footer
        </div>
    )
}