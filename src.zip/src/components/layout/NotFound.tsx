import '../style/notfound.scss'

export default function NotFound(){
    return (
        <div className="notfound">
            Error 404: Page Not Found
        </div>
    );
}