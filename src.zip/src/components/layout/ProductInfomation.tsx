import '../style/productinfomation.scss'

export default function ProductInfomation() {

    const name = "iPhone 14"
    const image = "/image/Iphone 14.jpg"
    const price = 1000000
    const priceDiscount = 9000000
    const quantity = 100
    const description = [
        { id: 1, description: "Description 1" },
        { id: 1, description: "Description 1" },
        { id: 1, description: "Description 1" },
    ]

    return (
        <div className='product_infomation'>
            <div>
                <img src={image} alt={name} />
                <div>{name}</div>
                <div>{price}</div>
                <div>{priceDiscount}</div>
                <div>{quantity}</div>
                {description.map(item => (
                    <ul>
                        <li>{item.description}</li>
                    </ul>
                ))}
            </div>
        </div>
    )
}