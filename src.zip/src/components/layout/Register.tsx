export default function Register(){
    return (
        <div className="register">
            This is Register
            </div>
    )
}